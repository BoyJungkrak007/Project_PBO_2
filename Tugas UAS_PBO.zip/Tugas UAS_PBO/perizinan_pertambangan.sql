-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2025 at 03:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perizinan_pertambangan`
--

-- --------------------------------------------------------

--
-- Table structure for table `bahan_perusahaan`
--

CREATE TABLE `bahan_perusahaan` (
  `kd_bahan_perusahaan` int(5) NOT NULL,
  `nama_bahan` varchar(50) NOT NULL,
  `harga_jual` varchar(30) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `status_bahan` varchar(40) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bahan_perusahaan`
--

INSERT INTO `bahan_perusahaan` (`kd_bahan_perusahaan`, `nama_bahan`, `harga_jual`, `satuan`, `status_bahan`, `keterangan`) VALUES
(1, 'Emas', '928000', 'gram', 'available', 'banyak bosq siap jual ada 7T otw beli lambo'),
(2, 'BatuBara', '90000', 'kilo', 'available', 'tersedia sekitar 900 ton'),
(3, 'Perak', '279000', 'kg', 'available', 'banyak banget bosq, ada 89 ton siap jual');

-- --------------------------------------------------------

--
-- Table structure for table `bahan_tambang`
--

CREATE TABLE `bahan_tambang` (
  `kd_bahan_tambang` int(5) NOT NULL,
  `nama_bahan` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bahan_tambang`
--

INSERT INTO `bahan_tambang` (`kd_bahan_tambang`, `nama_bahan`, `status`, `satuan`, `keterangan`) VALUES
(1, 'Emas', 'Banyak', 'Kg', 'Ditemukan emas antam hirangan bingkarungan behintalu sebanyak 100 kg'),
(2, 'BatuBara', 'Banyak', 'Ton', 'Masih dalam penyelidikan'),
(3, 'Nikel', 'Sedikit', 'Ton', 'Berkurang sejak meningkatnya permintaan EV');

-- --------------------------------------------------------

--
-- Table structure for table `izin_industri`
--

CREATE TABLE `izin_industri` (
  `no_reg_surat` int(5) NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal` varchar(30) NOT NULL,
  `isi` varchar(150) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `izin_industri`
--

INSERT INTO `izin_industri` (`no_reg_surat`, `tgl_surat`, `perihal`, `isi`, `keterangan`) VALUES
(1, '2024-11-12', 'Permintaan Izin Pertambangan', 'Minta izin tambang aja', 'Duit siap 500 juta'),
(2, '2024-07-19', 'Permintaan Izin Pertambakan', 'Minta izin tambak, ada ja pelicin ny', 'Duit siap 1M'),
(3, '2024-07-02', 'Permintaan Izin Tambang Emas', 'Di IKN ada amas antam behintalu', 'Modal banyak, siap tarus sampai infus 9M');

-- --------------------------------------------------------

--
-- Table structure for table `perusahaan`
--

CREATE TABLE `perusahaan` (
  `no_perusahaan` int(5) NOT NULL,
  `nm_perusahaan` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telpon` varchar(12) NOT NULL,
  `fax` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `perusahaan`
--

INSERT INTO `perusahaan` (`no_perusahaan`, `nm_perusahaan`, `alamat`, `telpon`, `fax`, `email`) VALUES
(1, 'Kelapa Sawit Inc', 'Kalimantan Timur, Jl. Pengangsaan Rt 40. Rw.02 No.89 ', '083151993670', '4232323', 'Kapibara@gmail.com'),
(2, 'Kubangan', 'Kalimantan Timur, Jl. Pengangsaan Rt 40. Rw.02 No.89 ', '083157889872', '231133', 'Kapibara2@gmail.com'),
(3, 'naikmobil', 'Kalimantan Timur, Jl.Cendrawasih Rt.50 Rw.4 No.29 ', '083157228973', '913911', 'Kapibara3@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bahan_perusahaan`
--
ALTER TABLE `bahan_perusahaan`
  ADD PRIMARY KEY (`kd_bahan_perusahaan`);

--
-- Indexes for table `bahan_tambang`
--
ALTER TABLE `bahan_tambang`
  ADD PRIMARY KEY (`kd_bahan_tambang`);

--
-- Indexes for table `izin_industri`
--
ALTER TABLE `izin_industri`
  ADD PRIMARY KEY (`no_reg_surat`);

--
-- Indexes for table `perusahaan`
--
ALTER TABLE `perusahaan`
  ADD PRIMARY KEY (`no_perusahaan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bahan_perusahaan`
--
ALTER TABLE `bahan_perusahaan`
  MODIFY `kd_bahan_perusahaan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bahan_tambang`
--
ALTER TABLE `bahan_tambang`
  MODIFY `kd_bahan_tambang` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `izin_industri`
--
ALTER TABLE `izin_industri`
  MODIFY `no_reg_surat` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `perusahaan`
--
ALTER TABLE `perusahaan`
  MODIFY `no_perusahaan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
