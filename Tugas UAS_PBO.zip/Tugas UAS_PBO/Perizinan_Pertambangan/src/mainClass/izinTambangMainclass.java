/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainClass;
import GUI.mainFrame;

/**
 *
 * @author acer
 */
public class izinTambangMainclass {
    public static void main(String[] args) {
        // TODO code application logic here
        new mainFrame().setVisible(true);
    }
}
